package com.hacxgpt.mobile;

import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.InputType;
import android.text.method.PasswordTransformationMethod;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends android.app.Activity {
    private static final int BG = Color.rgb(9, 11, 16);
    private static final int PANEL = Color.rgb(17, 21, 29);
    private static final int USER = Color.rgb(20, 65, 82);
    private static final int AI = Color.rgb(24, 29, 39);
    private static final int TEXT = Color.rgb(235, 241, 247);
    private static final int MUTED = Color.rgb(150, 163, 177);
    private static final int CYAN = Color.rgb(101, 216, 255);

    private LinearLayout messages;
    private ScrollView scroll;
    private EditText input;
    private TextView status;
    private SecureStore secure;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final List<JSONObject> history = new ArrayList<>();
    private Provider provider;
    private String model;
    private boolean sending = false;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG);
        secure = new SecureStore(this);
        provider = Provider.all().get(indexOfProvider(getPreferences(0).getString("provider", "groq")));
        model = getPreferences(0).getString("model", provider.models.get(0));
        buildUi();
        loadHistory();
    }

    private int indexOfProvider(String id) {
        List<Provider> list=Provider.all();
        for(int i=0;i<list.size();i++) if(list.get(i).id.equals(id)) return i;
        return 1;
    }

    private TextView tv(String text, float size, int color) {
        TextView v=new TextView(this); v.setText(text); v.setTextSize(size); v.setTextColor(color); v.setPadding(0,0,0,0); return v;
    }
    private Button button(String label) {
        Button b=new Button(this); b.setText(label); b.setTextColor(TEXT); b.setAllCaps(false); return b;
    }

    private void buildUi() {
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(BG);
        LinearLayout bar=new LinearLayout(this); bar.setGravity(Gravity.CENTER_VERTICAL); bar.setPadding(18,10,10,8); bar.setBackgroundColor(PANEL);
        LinearLayout titleBox=new LinearLayout(this); titleBox.setOrientation(LinearLayout.VERTICAL);
        TextView title=tv("HacxGPT",21,CYAN); title.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        status=tv(provider.name+" • "+model,12,MUTED); titleBox.addView(title); titleBox.addView(status);
        bar.addView(titleBox,new LinearLayout.LayoutParams(0,-2,1));
        Button settings=button("⚙"); settings.setTextSize(22); settings.setOnClickListener(v->showSettings()); bar.addView(settings,new LinearLayout.LayoutParams(54,54));
        Button clear=button("＋"); clear.setTextSize(24); clear.setOnClickListener(v->clearChat()); bar.addView(clear,new LinearLayout.LayoutParams(54,54));
        root.addView(bar,new LinearLayout.LayoutParams(-1,72));

        scroll=new ScrollView(this); scroll.setFillViewport(true);
        messages=new LinearLayout(this); messages.setOrientation(LinearLayout.VERTICAL); messages.setPadding(12,16,12,20); scroll.addView(messages,new ScrollView.LayoutParams(-1,-2));
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout composer=new LinearLayout(this); composer.setPadding(10,8,10,10); composer.setGravity(Gravity.BOTTOM); composer.setBackgroundColor(PANEL);
        input=new EditText(this); input.setHint("Message HacxGPT..."); input.setHintTextColor(MUTED); input.setTextColor(TEXT); input.setTextSize(16); input.setGravity(Gravity.TOP); input.setMinLines(1); input.setMaxLines(6); input.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES); input.setPadding(14,12,14,12);
        composer.addView(input,new LinearLayout.LayoutParams(0,-2,1));
        Button send=button("➤"); send.setTextSize(23); send.setOnClickListener(v->sendMessage()); composer.addView(send,new LinearLayout.LayoutParams(58,58));
        root.addView(composer,new LinearLayout.LayoutParams(-1,-2));
        setContentView(root);
    }

    private void addBubble(String role,String text,boolean streaming) {
        LinearLayout wrap=new LinearLayout(this); wrap.setOrientation(LinearLayout.VERTICAL); wrap.setPadding(4,5,4,5);
        TextView label=tv(role.equals("user")?"YOU":"HACXGPT",11,role.equals("user")?CYAN:MUTED); label.setTypeface(Typeface.DEFAULT,Typeface.BOLD); wrap.addView(label);
        TextView body=tv(render(text),16,TEXT); body.setTextIsSelectable(true); body.setPadding(14,12,14,12); body.setBackgroundColor(role.equals("user")?USER:AI); wrap.addView(body,new LinearLayout.LayoutParams(-1,-2));
        if(!role.equals("user")) { body.setOnLongClickListener(v->{copy(text);return true;}); }
        messages.addView(wrap,new LinearLayout.LayoutParams(-1,-2));
        if(streaming) body.setTag("stream");
        scroll.post(()->scroll.fullScroll(View.FOCUS_DOWN));
    }

    private TextView currentStreamingBody(){
        if(messages.getChildCount()==0) return null; View w=messages.getChildAt(messages.getChildCount()-1); if(!(w instanceof LinearLayout)) return null; View b=((LinearLayout)w).getChildAt(1); return b instanceof TextView?(TextView)b:null;
    }
    private void updateStreaming(String text){ TextView body=currentStreamingBody(); if(body!=null){body.setText(render(text)); scroll.post(()->scroll.fullScroll(View.FOCUS_DOWN));} }

    private String render(String s){
        // Lightweight Markdown-friendly rendering that works without a third-party library.
        return s.replace("```", "\n──────── CODE ────────\n");
    }
    private void copy(String text){ ClipboardManager cm=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE); cm.setPrimaryClip(ClipData.newPlainText("HacxGPT",text)); Toast.makeText(this,"Copied",Toast.LENGTH_SHORT).show(); }

    private void sendMessage(){
        if(sending) return; String text=input.getText().toString().trim(); if(text.isEmpty()) return;
        String key=secure.get("api_key_"+provider.id); if(key.isEmpty()){ showSettings(); Toast.makeText(this,"Add an API key first",Toast.LENGTH_SHORT).show(); return; }
        sending=true; input.setEnabled(false); input.setText("");
        try { JSONObject user=new JSONObject(); user.put("role","user"); user.put("content",text); history.add(user); saveHistory(); addBubble("user",text,false); addBubble("assistant","",true); }
        catch(Exception e){ sending=false; input.setEnabled(true); return; }
        final String base=provider.baseUrl, keyFinal=key, modelFinal=model;
        final List<JSONObject> requestHistory=new ArrayList<>();
        if (!provider.id.equals("hacxgpt")) { try { JSONObject sys=new JSONObject(); sys.put("role","system"); sys.put("content",loadSystemPrompt()); requestHistory.add(sys); } catch(Exception ignored){} }
        requestHistory.addAll(history);
        executor.execute(()->ApiClient.chat(base,keyFinal,modelFinal,requestHistory,new ApiClient.Listener(){
            StringBuilder response=new StringBuilder();
            @Override public void onChunk(String chunk){ response.append(chunk); runOnUiThread(()->updateStreaming(response.toString())); }
            @Override public void onDone(){ runOnUiThread(()->{ try{JSONObject ai=new JSONObject(); ai.put("role","assistant"); ai.put("content",response.toString()); history.add(ai); saveHistory();}catch(Exception ignored){} sending=false; input.setEnabled(true); input.requestFocus(); }); }
            @Override public void onError(String message){ runOnUiThread(()->{ updateStreaming("Error: "+message); sending=false; input.setEnabled(true); }); }
        }));
    }

    private void clearChat(){ new AlertDialog.Builder(this).setTitle("Clear conversation?").setMessage("This removes the saved chat history on this device.").setNegativeButton("Cancel",null).setPositiveButton("Clear",(d,w)->{history.clear(); saveHistory(); messages.removeAllViews(); Toast.makeText(this,"Conversation cleared",Toast.LENGTH_SHORT).show();}).show(); }

    private void showSettings(){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(34,8,34,4);
        Spinner providerSpin=new Spinner(this); List<Provider> providers=Provider.all(); List<String> names=new ArrayList<>(); for(Provider p:providers)names.add(p.name); providerSpin.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,names)); providerSpin.setSelection(indexOfProvider(provider.id)); box.addView(label("Provider")); box.addView(providerSpin);
        Spinner modelSpin=new Spinner(this); box.addView(label("Model")); box.addView(modelSpin);
        EditText key=new EditText(this); key.setHint("API key"); key.setTextColor(TEXT); key.setHintTextColor(MUTED); key.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD); key.setTransformationMethod(PasswordTransformationMethod.getInstance()); box.addView(label("API key")); box.addView(key);
        providerSpin.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){ public void onNothingSelected(android.widget.AdapterView<?> p){} public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){Provider pp=providers.get(pos); modelSpin.setAdapter(new ArrayAdapter<>(MainActivity.this,android.R.layout.simple_spinner_dropdown_item,pp.models)); int mi=pp.models.indexOf(model); modelSpin.setSelection(Math.max(0,mi)); key.setText(secure.get("api_key_"+pp.id));}});
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Settings").setView(box).setNegativeButton("Cancel",null).setPositiveButton("Save",null).create();
        dialog.setOnShowListener(x->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{Provider pp=providers.get(providerSpin.getSelectedItemPosition()); String mm=(String)modelSpin.getSelectedItem(); String kk=key.getText().toString().trim(); if(kk.isEmpty()){key.setError("Enter an API key");return;} secure.put("api_key_"+pp.id,kk); boolean providerChanged=!provider.id.equals(pp.id); provider=pp; model=mm; getPreferences(0).edit().putString("provider",pp.id).putString("model",mm).apply(); status.setText(provider.name+" • "+model); if(providerChanged){ history.clear(); saveHistory(); messages.removeAllViews(); } dialog.dismiss(); Toast.makeText(this,"Settings saved",Toast.LENGTH_SHORT).show();});
        dialog.show();
        providerSpin.setSelection(indexOfProvider(provider.id)); key.setText(secure.get("api_key_"+provider.id));
        modelSpin.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,provider.models)); modelSpin.setSelection(Math.max(0,provider.models.indexOf(model)));
    }
    private TextView label(String s){ TextView v=tv(s,12,MUTED); v.setPadding(0,12,0,4); return v; }

    private void saveHistory(){ try{JSONArray a=new JSONArray(); for(JSONObject o:history)a.put(o); getPreferences(0).edit().putString("history",a.toString()).apply();}catch(Exception ignored){} }
    private void loadHistory(){ try{String raw=getPreferences(0).getString("history",""); if(raw.isEmpty())return; JSONArray a=new JSONArray(raw); for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);history.add(o);addBubble(o.optString("role"),o.optString("content"),false);}}catch(Exception ignored){} }
    private String loadSystemPrompt(){ try{BufferedReader r=new BufferedReader(new InputStreamReader(getAssets().open("system_prompt.md"),StandardCharsets.UTF_8));StringBuilder s=new StringBuilder();String l;while((l=r.readLine())!=null)s.append(l).append('\n');return s.toString();}catch(Exception e){return "You are HacxGPT.";} }
    @Override protected void onDestroy(){executor.shutdownNow();super.onDestroy();}
}
