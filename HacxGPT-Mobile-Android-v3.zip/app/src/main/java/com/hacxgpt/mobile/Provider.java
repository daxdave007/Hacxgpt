package com.hacxgpt.mobile;

import java.util.Arrays;
import java.util.List;

final class Provider {
    final String id, name, baseUrl;
    final List<String> models;
    Provider(String id, String name, String baseUrl, String... models) {
        this.id=id; this.name=name; this.baseUrl=baseUrl; this.models=Arrays.asList(models);
    }
    static List<Provider> all() {
        return Arrays.asList(
            new Provider("hacxgpt", "HacxGPT", "https://api.hacxgpt.com/v1", "hacxgpt-lightning"),
            new Provider("groq", "Groq", "https://api.groq.com/openai/v1", "moonshotai/kimi-k2-instruct-0905", "qwen/qwen3-32b"),
            new Provider("openrouter", "OpenRouter", "https://openrouter.ai/api/v1", "xiaomi/mimo-v2-flash", "mistralai/devstral-2512", "z-ai/glm-4.5-air", "moonshotai/kimi-k2")
        );
    }
}
