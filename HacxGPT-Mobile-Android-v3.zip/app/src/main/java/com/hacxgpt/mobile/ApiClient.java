package com.hacxgpt.mobile;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.List;

final class ApiClient {
    interface Listener { void onChunk(String text); void onDone(); void onError(String message); }

    private static void emitJsonDelta(String payload, Listener listener) {
        try {
            JSONObject obj = new JSONObject(payload);
            JSONArray choices = obj.optJSONArray("choices");
            if (choices == null || choices.length() == 0) return;
            JSONObject choice = choices.optJSONObject(0);
            if (choice == null) return;
            JSONObject delta = choice.optJSONObject("delta");
            String text = delta != null ? delta.optString("content", "") : choice.optJSONObject("message") != null ? choice.optJSONObject("message").optString("content", "") : "";
            if (!text.isEmpty()) listener.onChunk(text);
        } catch (Exception ignored) { }
    }

    static void chat(String baseUrl, String apiKey, String model, List<JSONObject> history, Listener listener) {
        HttpURLConnection conn = null;
        try {
            URL url = new URL(baseUrl.replaceAll("/$", "") + "/chat/completions");
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setConnectTimeout(20000);
            conn.setReadTimeout(90000);
            conn.setDoOutput(true);
            conn.setRequestProperty("Authorization", "Bearer " + apiKey);
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            conn.setRequestProperty("Accept", "text/event-stream, application/json");
            if (baseUrl.contains("openrouter.ai")) {
                conn.setRequestProperty("HTTP-Referer", "https://github.com/HacxGPT-Official/HacxGPT-CLI");
                conn.setRequestProperty("X-Title", "HacxGPT Mobile");
            }
            JSONObject body = new JSONObject();
            body.put("model", model);
            JSONArray messages = new JSONArray();
            for (JSONObject m : history) messages.put(m);
            body.put("messages", messages);
            body.put("stream", true);
            body.put("temperature", 0.75);
            byte[] data = body.toString().getBytes(StandardCharsets.UTF_8);
            OutputStream out = conn.getOutputStream(); out.write(data); out.flush(); out.close();

            int code = conn.getResponseCode();
            InputStream raw = code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream();
            StringBuilder error = new StringBuilder();
            if (code < 200 || code >= 300) {
                if (raw != null) {
                    BufferedReader er = new BufferedReader(new InputStreamReader(raw, StandardCharsets.UTF_8));
                    String line; while ((line=er.readLine()) != null) error.append(line);
                }
                listener.onError("HTTP " + code + (error.length() > 0 ? ": " + error : "")); return;
            }
            BufferedReader reader = new BufferedReader(new InputStreamReader(raw, StandardCharsets.UTF_8));
            String line;
            StringBuilder plainJson = new StringBuilder();
            boolean sawSse = false;
            while ((line = reader.readLine()) != null) {
                if (!line.startsWith("data:")) { if (!sawSse && line.trim().startsWith("{")) plainJson.append(line.trim()); continue; }
                sawSse = true;
                String payload = line.substring(5).trim();
                if (payload.isEmpty()) continue;
                if ("[DONE]".equals(payload)) break;
                emitJsonDelta(payload, listener);
            }
            if (!sawSse && plainJson.length() > 0) emitJsonDelta(plainJson.toString(), listener);
            listener.onDone();
        } catch (Exception e) {
            listener.onError(e.getClass().getSimpleName() + ": " + (e.getMessage() == null ? "Connection failed" : e.getMessage()));
        } finally { if (conn != null) conn.disconnect(); }
    }
}
