# Conversion notes

The supplied HacxGPT-CLI source is Python + Rich + prompt_toolkit and depends on a terminal. Those components cannot be converted into a useful native Android app by simply renaming the output to APK.

This Android project therefore reimplements the user-facing CLI features with Android SDK APIs:

- terminal menu -> native settings/chat UI
- Python HTTP client -> `HttpURLConnection`
- local `.hacx`/machine-bound Fernet storage -> Android Keystore AES-GCM storage
- CLI session history -> SharedPreferences JSON
- code-block save/copy workflow -> response long-press copy
- provider/model configuration -> native Settings dialog

The original system prompt is kept in `app/src/main/assets/system_prompt.md` and is sent to non-HacxGPT OpenAI-compatible providers to preserve the supplied CLI behavior.

No provider API key is embedded in the project.
