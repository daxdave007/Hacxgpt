# HacxGPT Mobile (Android)

A native Android client for HacxGPT-compatible OpenAI-style chat APIs.
This is a real API client, not a UI-only wrapper.

## Requirements
- Android Studio / Android SDK, or GitHub Codespaces
- Java 17
- Internet access when Gradle is first downloaded and when using the AI APIs
- An API key for the selected provider

## Build in GitHub Codespaces

```bash
chmod +x ./gradlew
./gradlew assembleDebug
```

The launcher uses Gradle 8.10.2. If Gradle is already installed, it uses that executable; otherwise it downloads the pinned Gradle distribution into `.gradle-local/`.

APK:
`app/build/outputs/apk/debug/app-debug.apk`

## GitHub Actions

Push to `main`/`master`, or run **Build Android APK** manually under Actions. The workflow installs Java 17, Android SDK 35/build-tools 35.0.0, then builds with the same `./gradlew` launcher.

## App functionality
- Native Android chat UI
- Real HTTPS chat-completion requests
- Streaming responses
- HacxGPT, Groq and OpenRouter provider presets
- Model selection
- Encrypted API-key storage using Android Keystore
- Local conversation history
- Clear conversation
- Copy assistant responses
- Network/API error messages

API keys and network access are required for actual AI responses.
